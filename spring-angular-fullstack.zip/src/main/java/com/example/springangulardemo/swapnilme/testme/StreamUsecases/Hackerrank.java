package com.example.springangulardemo.swapnilme.testme.StreamUsecases;

import java.util.HashMap;
import java.util.Map;

public class Hackerrank {
    Hackerrank(String name){
        System.out.println("in 1");

    }

    Hackerrank(String name ,boolean ishacker){
        System.out.println("in 2");
    }

    public static void main(String[] args) {
       // Hackerrank h= new Hackerrank("d",true);
        Hackerrank h= new Hackerrank("d");
        HashMap<Integer,String> map = new HashMap<>();
        System.out.println("-------------");
        map.put(1,"I");
        map.put(2,"Love");
        map.put(3,"coding");
        map.put(1,"I Love coding");


        for(Map.Entry m: map.entrySet()){
            System.out.println(m.getKey() + "" +m.getValue());
        }

        String name="Hackerearth";
        for(int i=0;i< name.length();i++){
            System.out.println(name.charAt(i+1));
        }
    }
}
