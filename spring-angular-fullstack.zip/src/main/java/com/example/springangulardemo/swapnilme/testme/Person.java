package com.example.springangulardemo.swapnilme.testme;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;


@Data
@NoArgsConstructor
@AllArgsConstructor
public class Person {
    private String name;
    private String city;
    private String country;



    public  static List<Person> getprepaperdata(){
        Person p = new Person("swapnil","bhusawal","India");
        Person p1 = new Person("Rushikesh","Bid","India");
        Person p5 = new Person("suraj","pune","India");
        Person p2 = new Person("Andrue","california","USA");
        Person p6 = new Person("peter","danmark","USA");
        Person p3 = new Person("rutuja","ali","NewYork");
        Person p4 = new Person("rutuja","Falkon","NewYork");
        return Arrays.asList(p,p1,p2,p3,p4,p5,p6);
    }

    public static void main(String[] args) {

        List<Person> data = getprepaperdata();
        System.out.println(data.size());

        Map<String, List<Person>> s = data.stream().collect(Collectors.groupingBy(Person::getCountry));
        s.entrySet().forEach(System.out::println);

        System.out.println("-------------------------------------------------");
        Map<String, Map<String, List<Person>>> collect = data.
                stream().
                collect(Collectors.groupingBy(Person::getCountry, TreeMap::new ,Collectors.groupingBy(Person::getCity)));
        System.out.println(collect);
        Vector<Person> collect1 = data.stream().collect(Collectors.toCollection(Vector::new));

//        data.stream()
//                .collect(Collectors.groupingBy(Person::getCity, Collectors.counting()));
//

        System.out.println("==========================================================================");

        Arrays.asList(10, 23, -4, 0, 18)
                .stream().
                  sorted(Collections.reverseOrder()).
                   forEach(System.out::println);

        System.out.println("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
        List<Integer> l1 =Arrays.asList(10, 23, -4, 0, 18,-10);
        Collections.sort(l1);
        System.out.println(l1);

        System.out.println("////////////////////////////////////////////////////////////////////////");
        Map<String, Map<String, List<Person>>> collect2 = data.stream().collect(Collectors.groupingBy((x) -> x.getName(), Collectors.groupingBy(y -> y.getCountry())));
        System.out.println(collect2);













    }

}
