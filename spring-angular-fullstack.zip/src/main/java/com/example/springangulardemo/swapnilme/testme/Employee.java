package com.example.springangulardemo.swapnilme.testme;

import com.fasterxml.jackson.databind.util.JSONPObject;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.json.JSONException;
import org.json.JSONObject;


@Data
@NoArgsConstructor
@AllArgsConstructor
public class Employee {

    private int empid;
    private int age;
    private String name;
    private int marks[];

    public static void main(String[] args) throws JSONException {

        JSONObject site = new JSONObject();
        site.put("fname","swapnil");
        site.put("lname",null);
         if(site.get("lname") != null){
            if(String.valueOf(site.get("lname")).length() > 0 ){
                System.out.println("present");
            }else{
                System.out.println("lastname is emplty");
            }

        }







    }
}
