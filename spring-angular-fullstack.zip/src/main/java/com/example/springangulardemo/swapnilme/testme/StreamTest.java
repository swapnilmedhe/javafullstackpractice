package com.example.springangulardemo.swapnilme.testme;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class StreamTest {

    private static TempStudent tmpStud2;

    public static void main(String[] args) {
        Student student1 = new Student(
                "Jayesh",
                20,
                new Address("1234"),
                Arrays.asList(new MobileNumber("1233"), new MobileNumber("1234")));
        Student student2 = new Student(
                "Khyati",
                20,
                new Address("1235"),
                Arrays.asList(new MobileNumber("1111"), new MobileNumber("3333"), new MobileNumber("1233")));
        Student student3 = new Student(
                "Jason",
                20,
                new Address("1236"),
                Arrays.asList(new MobileNumber("3333"), new MobileNumber("4444")));
        Student student4 = new Student(
                "Swapnil",
                20,
                new Address("1236"),
                Arrays.asList(new MobileNumber("1233"), new MobileNumber("1234")));
        List<Student> students = Arrays.asList(student1, student2, student3, student4);


         // web :  https://javabypatel.blogspot.com/2018/06/java-8-stream-practice-problems.html
        /* practice questions are below .............................................................*/

        //   Get student with exact match name "jayesh"

        Set Result = students.stream().filter(x -> x.getName().equals("Jayesh"))
                .collect(Collectors.toSet());
        System.out.println(Result);
        System.out.println("-----------------------------------------------------------");

        // get student with matching address "1235"st

        students.stream().filter(x -> Objects.nonNull(x.getAddress())).collect(Collectors.toList());
        System.out.println("-----------------------------------------------------------");


        //  Get all student having mobile numbers 3333.

        students.stream().filter(student -> student.getMobileNumbers().stream().anyMatch(x -> x.getNumber().equals("3333"))).forEach(System.out::println);
//                anyMatch(x -> Objects.equals(x.getNumber(), "3333")))
//                .forEach(System.out::println);
        System.out.println("-----------------------------------------------------------");


        //Get all student having mobile numbers 1233 and 1234
        List<Student> stud3 = students.stream()
                .filter(student -> student.getMobileNumbers().stream().allMatch(x -> Objects.equals(x.getNumber(), "1233") || Objects.equals(x.getNumber(), "1234")))
                .collect(Collectors.toList());


        List<Student> std = students.stream().filter(student -> student.getMobileNumbers().stream().allMatch(x -> Objects.equals(x.getNumber(), "1233")
                || Objects.equals(x.getNumber(), "1234"))).collect(Collectors.toList());
        std.stream().map(x -> x.getName()).forEach(System.out::println);
        System.out.println("-----------------------------------------------------------");


        // Create a List<Student> from the List<TempStudent>
        TempStudent tmpStud1 = new TempStudent(
                "Jayesh1",
                201,
                new Address("12341"),
                Arrays.asList(new MobileNumber("12331"), new MobileNumber("12341")));
        TempStudent tmpStud2 = new TempStudent(
                "Khfati1",
                202,
                new Address("12351"),
                Arrays.asList(new MobileNumber("11111"), new MobileNumber("33331"), new MobileNumber("12331")));
        List<TempStudent> tmpStudents = Arrays.asList(tmpStud1, tmpStud2);

        List<Student> studentList =tmpStudents.stream().map( tempStudent -> new Student(tempStudent.name,tempStudent.age,tempStudent.address,tempStudent.mobileNumbers)).collect(Collectors.toList());
         System.out.println(studentList);
        System.out.println("-----------------------------------------------------------");

        // Convert List<Student> to List<String> of student name

        List<String> l= students.stream().map(x-> x.getName()).collect(Collectors.toList());
        System.out.println(l);
        System.out.println( l.stream().collect(Collectors.joining(";","[", "]")));
        System.out.println("-----------------------------------------------------------");

        // sort the list
        List<String> namesList =
                Arrays.asList("Jayesh", "Dany", "Khyati", "Hello", "Mango");

        namesList.stream().sorted().forEach(System.out::println);


        //   Conditionally apply Filter condition, say if flag is enabled then
        boolean sortConditionFlag =true;
        Stream<Student> conditionalFilterResult = students.stream()
                .filter(st -> st.getName().startsWith("J"));

        if(sortConditionFlag){
            conditionalFilterResult = conditionalFilterResult.sorted(Comparator.comparing(Student::getName));
        }

        System.out.println("Before sorting :");
        students.forEach(s -> System.out.println(s.getName()));

        List<Student> list = conditionalFilterResult.collect(Collectors.toList());
        System.out.println("After filter and conditional sorting :");
        list.forEach(s -> System.out.println(s.getName()));

        //  addition of the  number

        List<Integer> integers = Arrays.asList(1, 2, 3, 4, 5);

       int sum= integers.stream().reduce(0,(a ,b) -> a+b);
        System.out.println(sum);

       Optional<Integer> x= integers.stream().reduce( (e, y) -> e*y);
        System.out.println(x);


        List<Integer> integersList = Arrays.asList(1, 2, 3, 4, 5,8,10,11,12);
        // find out the only integer name
        System.out.println("=======================================================");

        integersList.stream().filter( z -> z%2 ==0).forEach(System.out::println);
        System.out.println("=======================================================");
        List<Integer> even= new ArrayList<>();
        List<Integer> odd= new ArrayList<>();

        integersList.stream().filter( c -> {
            if (c % 2 == 0){
                System.out.println("->"+c);
                even.add(c);
                return true;
            }
            odd.add(c);
            return false;
        }).collect(Collectors.toList());


        System.out.println(even);
        System.out.println(odd);


        System.out.println("----------------------------------------------------------------------------------");


        students.stream().forEach(System.out::println);
        System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");

         Map<Object ,List<Student>> los =  students.stream().collect(Collectors.groupingBy(f -> f.getName()));
        System.out.println(los);

    }
}
