package com.example.springangulardemo.swapnilme.testme.CompatibleFuture;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

public class CompletableFutureTest {
    public static void main(String[] args) throws ExecutionException, InterruptedException {

        CompletableFuture<String> completableFuture1 = CompletableFuture.supplyAsync(()->{
            try {
                TimeUnit.SECONDS.sleep(2);

            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            return "hello";
        });

        CompletableFuture<String> completableFuture2 = CompletableFuture.supplyAsync(()->{
            try {
                TimeUnit.SECONDS.sleep(2);

            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            return "swapnil ";
        });

        CompletableFuture<String> completableFuture3 = CompletableFuture.supplyAsync(()->{
            try {
                TimeUnit.SECONDS.sleep(2);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            return "Welcome back .....";
        });

        Throwable r = new Throwable("sf");
        completableFuture2.exceptionally( t-> t.getMessage());
    //    System.out.println( "+++++++++++++"+       completableFuture2.get());

//        CompletableFuture<Void> resulr= CompletableFuture.allOf(completableFuture1,completableFuture2,completableFuture3);
//
   //     CompletableFuture<String> result = completableFuture1.thenApply(name-> name)
      //  System.out.println(result.get());


/*        Void join = CompletableFuture.allOf(completableFuture1, completableFuture3, completableFuture2)
                .thenAccept(b->b).thenRun(()-> System.out.println("all task complited"));*/



    }
}
