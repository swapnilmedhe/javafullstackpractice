package com.example.springangulardemo.swapnilme.testme;

import java.util.Arrays;
import java.util.Collections;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class StreamPractice {
    public static void main(String[] args) {

        /*find out 1 st eelemnts of the stram*/

        System.out.println(       Stream.of( "Geek_First","Geek_2","Geek_3").reduce( (first,second) -> first).orElse(null));

        System.out.println(Stream.of( "Geek_First","Geek_2","Geek_3").findFirst().get());


        /* find out last elemnts of the stream */
         String input[] ={"Geek_First","Geek_2","Geek_3","Geek_last"};
        System.out.println(Stream.of( "Geek_First","Geek_2","Geek_3","Geek_last").skip(Stream.of( "Geek_First","Geek_2","Geek_3","Geek_last").count()-1).findFirst().get());

        Arrays.stream(input).sorted(Collections.reverseOrder()).findFirst().get();

        System.out.println("==========================================================");

        System.out.println(Arrays.stream(input).sorted(Collections.reverseOrder()).findFirst().get());


    }
}
