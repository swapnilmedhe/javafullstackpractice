package com.example.springangulardemo.swapnilme.testme.CompatibleFuture;

import java.io.BufferedReader;
import java.io.InputStreamReader;

import static java.lang.Thread.*;

public class ThreadJoinMethodDemo {

    ThreadJoinMethodDemo(){
        System.out.println("Hi");
    }
    public static void main(String[] args) throws InterruptedException {


        ThreadJoinMethodDemo t = new ThreadJoinMethodDemo();
        ThreadJoin t1 = new ThreadJoin();
        ThreadJoin t2 = new ThreadJoin();
        ThreadJoin t3 = new ThreadJoin();

        t1.setName("First Thread");
        t1.start();
        //t1.setPriority(11);
        System.out.println("t1 ->"+t1.getPriority()+t1.getName());
         t1.join();


        t2.setName("Second Thread");
        t2.start();
        t2.setPriority(MAX_PRIORITY);
        System.out.println("t2  ->"+t2.getPriority()+t2.getName());

       // t2.join();



        t3.setName("Third Thread");
        t3.start();
        t3.setPriority(NORM_PRIORITY);
        System.out.println("t3  ->"+t3.getPriority() + t3.getName());

       // t3.join();
    }
    }
    @FunctionalInterface
interface x{
    public void test();

    default public void me(){
        System.out.println("its default");
    }

     default public void me1(){
         System.out.println("its default");
     }
}

class Dem implements x{

    @Override
    public void test() {

    }


}
class ThreadJoin extends Thread {

    public void run() {


        BufferedReader reader = new BufferedReader( new InputStreamReader(System.in))  ;
        for(int i=0; i<2 ; i++) {

            try {

                System.out.println("The current thread name is: " + Thread.currentThread().getName());

                Thread.sleep(1000);
//                for(;;){
//                    System.out.println("wel");
//
//                }


            }catch(InterruptedException e) {

                e.printStackTrace();

            }

        }

    }

}

