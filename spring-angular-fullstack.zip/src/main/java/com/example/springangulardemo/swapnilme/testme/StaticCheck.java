package com.example.springangulardemo.swapnilme.testme;

public  class StaticCheck {

    public static void print(){
        System.out.println("its a static method");
    }

    public  void printme(){
        System.out.println("its a non-static method");
    }

//
//    public static  void main(String[] args) {
//        StaticCheck ch = new StaticCheck();
//        ch.printme();
//        ch.print();
//    }

    static {
        StaticCheck ch = new StaticCheck();
        ch.printme();
        ch.print();
    }
}
