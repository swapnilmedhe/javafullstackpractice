package com.example.springangulardemo.swapnilme.testme.CompatibleFuture;

import com.example.springangulardemo.swapnilme.testme.StreamUsecases.Employees;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.File;
import java.util.List;
import java.util.concurrent.CompletableFuture;

public class RunAsyncDemo {

    /* if we dont expect any return type then go for the Run Async method of comletableFuture */





    public static void main(String[] args) {

    }


}
