package com.example.springangulardemo.swapnilme.testme.CompatibleFuture;

import ch.qos.logback.core.util.TimeUtil;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

public class FeatureDemo {
    public static void main(String[] args) throws ExecutionException, InterruptedException {

        Future<Object> futureObj= Executors.newSingleThreadExecutor().submit(()->{
            TimeUnit.SECONDS.sleep(2);

            return "Hello";
        });

        while (!futureObj.isDone()){
            System.out.println("In process ................");
//            futureObj.cancel(futureObj.isDone());
        }

        System.out.println(futureObj.get());



    }
}
