package com.example.springangulardemo.swapnilme.testme;

import java.sql.SQLOutput;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

public class UserTest {
    public static void main(String[] args) {
            List<User> userList = new ArrayList<>(
                Arrays.asList(
                new User("John", 33),
                new User("Robert", 26),
                new User("Mark", 26),
                new User("Abdul", 26),
                new User("Tarzan", 58),
                new User("Brandon", 42)));

        System.out.println("##########################################################################");
        userList.stream().forEach(System.out::println);

        System.out.println("-----------------------------------------------------------");
        Map<Integer, List<User>> collect = userList.stream().collect(Collectors.groupingBy(User::getAge));
        System.out.println(collect);

        System.out.println("-----------------------------------------------------------");
        List<User> collect1 = userList.stream().sorted(Comparator.comparingInt(User::getAge)).collect(Collectors.toList());
        System.out.println(collect1);

        Comparator<User> com= (obj1 ,obj2)-> obj1.getName().compareTo(obj2.getName());
        List<User> collect2 = userList.stream().sorted((o1, o2) -> o1.getName().compareTo(o2.getName())).collect(Collectors.toList());
        System.out.println(collect2);

        System.out.println("------------------------------------------------------");

        List<User> collect3 = userList.stream().sorted(com).collect(Collectors.toList());
        System.out.println(collect3);

        System.out.println("++++++++++++++++++");
      /* userList.stream()
                .collect(Collectors.summarizingLong(Comparator.comparing(User::getAge)));

        System.out.println(collect4);*/
        System.out.println("----------------------------------------------------");
        List<Integer> primes = Arrays.asList(2, 3, 5, 7, 11, 13, 17, 19, 23, 29);

        IntSummaryStatistics intSummaryStatistics = primes.stream().mapToInt(x -> x).summaryStatistics();
        System.out.println(intSummaryStatistics.getAverage());

        List<String> slist = Arrays.asList("Tanu", "Kamal", "Suman", "Lucky", "Bunty", "Amit");
        List<String> sortedList = slist.stream().sorted(Comparator.reverseOrder()).collect(Collectors.toList());

        System.out.println(sortedList);


        System.out.println("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
        String input="I am devloper".replace(" ","");

       Map<String,Long> mymap= Arrays.stream(input.split("")).map(x->x.toUpperCase())
                .collect( Collectors.groupingBy( Function.identity() ,Collectors.counting()));

        System.out.println(mymap);


        List<String> sorted=Arrays.stream(input.split(""))
                .map(x -> x.toLowerCase())
                .filter( y->ifPalindrome(y) )
                .sorted((a,b)-> a.compareTo(b)).collect(Collectors.toList());

        System.out.println(sorted);


        System.out.println("///////////////");
        String input2= "single word palindromes anna level racecar mom noon anna level";

        Map<String, Long> collect4 = Arrays.stream(input2.split(" "))
                .map(x -> x.toLowerCase())
                .filter(y-> ifPalindrome(y))
                .collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));

        System.out.println(collect4);


    }

    //pbg
    private static boolean ifPalindrome(String input){
        String original= input;
        String modify=null;
        StringBuilder builder= new StringBuilder(input);
        modify =builder.reverse().toString();
        if( original.equals(modify)){
            return true;
        }
        return false;
    }

}
