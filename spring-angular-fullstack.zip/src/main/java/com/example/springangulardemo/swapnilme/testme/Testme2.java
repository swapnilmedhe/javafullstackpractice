package com.example.springangulardemo.swapnilme.testme;


import java.util.*;
import java.util.stream.Collectors;

public class Testme2 {
    public static void main(String[] args) {

        List<Employee> employeeList= Arrays.asList(
        new Employee(12,25,"dinesh",new int[] {10,20,23}),
        new Employee(32,24,"pooja",new int[] {40,50,23}),
        new Employee(11,23,"swapnil",new int[] {40,50,23}),
        new Employee(4,25,"rushikesh",new int[] {20,50,23}),
        new Employee(15,23,"alex",new int[] {20,50,23}),
        new Employee(61,23,"Jimmy joshn",new int[] {20,50,23}));

         // sout
        System.out.println( employeeList);
        // convert the list to map having  employeeId is key and  name as a value
       /*note :  map never mentain the order */


        Map<Integer,String > map=employeeList.stream().collect(Collectors.toMap(Employee::getEmpid ,Employee::getName));
        System.out.println(map);
        System.out.println("*****************************************************************************");

        //  sorted map

        Map<Integer,String> orderddata= new LinkedHashMap<>();

        Map<Integer,String> datamap=  employeeList.stream().collect(Collectors.toMap(Employee::getEmpid, Employee::getName)) ;
           //    System.out.println( "++++>"+datamap);

       datamap.entrySet().stream().
               sorted(Map.Entry.<Integer,String>comparingByKey())
               .forEachOrdered( x-> orderddata.put(x.getKey(),x.getValue()) );
        System.out.println( "++++>"+orderddata);

        //  sorting for the primitative data type

        List intList = Arrays.asList(12,1,3,34,1223,90);
        intList.stream().sorted(Comparator.reverseOrder()).forEach(System.out::println);




    }
}
