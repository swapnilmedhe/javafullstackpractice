package com.example.springangulardemo.swapnilme.testme.programing;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class PTest2 {

    public static int fibonacci(int number){
        if(number <=1){
            return number;
        }

        return ( fibonacci(number-1) + fibonacci(number-2));
    }

    public static int factorial(int num){
        if(num ==1){
            return 1;
        }else{

            return (num * factorial(num -1));
        }
    }



    public static void main(String[] args) {
        int number =6;
        System.out.println(  fibonacci(6));


        /*  integer reverse ....*/

        int test= 123;


        int rev = 0,remider =0;
        while (test >0){
            remider= test %10;
            rev= rev *10 +remider;
            test = test /10;
        }

        System.out.println("rev =>>>>> "+rev);


        /* check vovels contain in the string */
        String vowels ="Helloi";
        System.out.println("??????????????????????");
        Arrays.stream(vowels.split("")).filter(x-> x.matches(".*[aeiou].*")).forEach(System.out::println);

        String s = "  abc  def\t";
        System.out.println(s);
        s = s.trim().replace(" " ,"?");
        System.out.println(s);

        /* factorial program
        * */

        System.out.println("----------------------------------------");
        System.out.println(PTest2.factorial(5));

        /*sun of all integer in array*/
        int[] array = { 1, 2, 3, 4, 5 };
        int result =Arrays.stream(array).reduce(0,(a,b)-> a+b);
        System.out.println("----------------------------------------");
        System.out.println(result);


        /* sorting of the hashmap ..*/

        Map<String, Integer> scores = new HashMap<>();
        scores.put("David", 95);
        scores.put("Jane", 80);
        scores.put("Mary", 97);
        scores.put("Lisa", 78);
        scores.put("Dino", 65);
        System.out.println(";;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;");
        System.out.println("Original map"+scores);
        /*scores = sortByValue(scores);
        System.out.println(scores);*/
//       Comparator< Map<String, Integer> > com= (o1,o2)->o1.getValue() - o2.getValue();
        scores.entrySet().stream().sorted((o1,o2)->o1.getKey().compareTo(o2.getKey())).forEach(System.out::println);



        /*findout distinct charactor in the string*/
        String str1 = "abcdABCDabcd";

        Map<String, Long> collect = Arrays.stream(str1.split("")).
                distinct()
                .collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));
        System.out.println("--------------------------------------");
        System.out.println(collect);

/*        Arrays.stream(str4.split("")).
                map(data -> data.toLowerCase())
                .collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));*/
        
        String s3 = "JournalDev";
        int start = 1;
        char end = 5;
        System.out.println("////////////");
        System.out.println(start + end);
        System.out.println("^^^^^^^^^^^^^^^^");
        System.out.println(s3.substring(start, end));

    }
}
