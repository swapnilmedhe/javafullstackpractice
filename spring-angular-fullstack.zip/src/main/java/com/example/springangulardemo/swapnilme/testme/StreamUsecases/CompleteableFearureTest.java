package com.example.springangulardemo.swapnilme.testme.StreamUsecases;

import java.util.concurrent.CompletableFuture;

public class CompleteableFearureTest {
    public static void main(String[] args) {
        CompletableFuture completableFuture = new CompletableFuture();

    }
}
