package com.example.springangulardemo.swapnilme.controller;

import com.example.springangulardemo.swapnilme.exception.ResourceNotFoundException;
import com.example.springangulardemo.swapnilme.model.Employee;
import com.example.springangulardemo.swapnilme.repo.EmployeeRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Collections;
import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:4401")
@RequestMapping("/api/")
public class EmployeeController {

    @Autowired
    private EmployeeRepo repo;

    @GetMapping("/employee")
  //  @Scheduled(cron = "0/15 * * * * *")
    public List<Employee> getAllEmployee(){
        System.out.println(" Calling by sheduler ::::::::");
        return repo.findAll();
    }

    @PostMapping("/employee")
    public Employee addEmployee(@RequestBody Employee employee){
        System.out.println("Employee "+employee);
          return  repo.save(employee);

    }

    @GetMapping("/employee/{id}")
    public ResponseEntity<Employee> findEmployeeById(@PathVariable long id){

        Employee emp =repo.findById(id).orElseThrow(() -> new ResourceNotFoundException("Employee not found with  id"));
        return ResponseEntity.ok(emp);
    }


    @DeleteMapping("/employee/{id}")
    public ResponseEntity<Employee> deleteEmployeeById(@PathVariable long id){

        Employee emp =repo.findById(id).orElseThrow(() -> new ResourceNotFoundException("Employee not found with  id"));
        repo.delete(emp);
        return ResponseEntity.ok(emp);
    }

    @PutMapping("/employee/{id}")
    public ResponseEntity<Employee> updateEmployee(@RequestBody Employee employee,@PathVariable Long id){
        System.out.println("=====>"+employee);
        Employee emp = repo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Employee not exist with id :" + id));
        emp.setFirstName(employee.getFirstName());
        emp.setLastName(employee.getLastName());
        emp.setEmail(employee.getEmail());
        Employee updatedEmp=repo.save(emp);
        return ResponseEntity.ok(updatedEmp);
    }




}
