package com.example.springangulardemo.swapnilme.testme.programing;

import java.sql.SQLOutput;
import java.util.*;

import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;


public class ProgramingTest {
    public static void main(String[] args) {
        //Write a Java Program to reverse a string without using String inbuilt function.

        String str = "Automation";
        StringBuilder builder= new StringBuilder(str);
        String output = String.valueOf(builder.reverse());
        System.out.println( output);

        String str1 = "Automation";
        String output1= "";

        char x;

        for(int i=str1.length()-1; i >= 0; i--){
           output1=output1+str1.charAt(i);

        }

        System.out.println("====>"+output1);




        //Write a Java Program to swap two numbers using the third variable.
  int t1=23;
  int t2=90;

        System.out.println("before swap  x , y " + t1+","+t2);
        t1= t1+t2;
        System.out.println("  t1= t1+t2  "+ t1);

        t2= t1-t2;
        System.out.println("    t2= t1-t2  "+ t2);

        t1= t1-t2;
        System.out.println("  t1= t1- t2  "+ t1);

        System.out.println("after swap  x , y " + t1+","+t2);



        //Q #5) Write a Java Program to count the number of words in a string using HashMap.

        String str3 = "This this is is done by Saket Saket";
        String[] input=str3.toLowerCase().split(" ");

        System.out.println(str3);
        HashMap<String ,Integer> map = new HashMap<String, Integer>();

        for(int i=0 ; i< input.length; i++){
            if(map.containsKey(input[i])){
                map.put(input[i] , map.get(input[i])+ 1);

            }else{
                map.put(input[i] , 1);
            }
        }

        System.out.println(map);

        System.out.println("*********************************************************************************");

        char[] input1=str3.toLowerCase().trim().replace(" ","").toCharArray();
        System.out.println(input1);
        HashMap<Character,Integer> map2= new HashMap();
        for(int i=0 ; i< input1.length ; i++){

            if(map2.containsKey(input1[i])){
                map2.put(input1[i] , map2.get(input1[i]) +1);
            }else{
                map2.put(input1[i] , 1);
            }
        }

        System.out.println(map2);


        String s="swapnil";
        HashMap<Character,Integer> map3= new HashMap<>();
        for(int i=0; i< s.length(); i++){

            if(map3.containsKey(s.charAt(i))){
                map3.put( s.charAt(i) , map.get(s.charAt(i)) +1 );
               }else{
                map3.put( s.charAt(i) , 1 );
            }
            }

        System.out.println("-------------------------------------------");
        System.out.println(map3);

        System.out.println("###############################################");

        String str5 = "This this is is done by Saket Saket";

        Map<String, Long> collect = Arrays.stream(str5.split(" ")).
                map(String::toLowerCase)
                .collect(Collectors.groupingBy(p -> p, Collectors.counting()));
        System.out.println("$$$$$$$$$$$$$$$$$$$$$$");
        System.out.println(collect);

        Collectors.groupingBy(z->z,Collectors.counting());
        String ip= "Dipawali";
        Map<String, Long> collect1 = Arrays.stream(ip.split("")).map(String::toLowerCase)
                .collect(Collectors.groupingBy(z -> z, Collectors.counting()));
        System.out.println(collect1);


     //   Q #7) Write a Java Program to find whether a number is prime or not.

                List<Integer>  list = Arrays.asList(1,3,2,10,34,20,7,40,24);

        List<Integer> collect2 = list.stream().filter(num -> !(num % 2 == 0)).collect(Collectors.toList());
        System.out.println(":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::");
        System.out.println(collect2);


        //  Write a Java Program to find whether a string or number is palindrome or not.


        String std="9989";
        StringBuilder bd = new StringBuilder(std);
        String reverse = String.valueOf(bd.reverse());
        System.out.println("::::::");
        System.out.println(reverse);
        if(std.equals(reverse)){
            System.out.println("its a palindrome");
        }else{
            System.out.println("its not a palindrome");
        }

        // check the given number is palindrome OR not
        System.out.println("???????????????");
        int num =123;
        int reminder=0;
        int revnum=0;

        while(num !=0){
            reminder= num%10 ;
            revnum= revnum *10 +reminder;
            num= num/10;
        }

        System.out.println("Revnum:::"+ revnum);


    /*    int revnum=0;
        int reminder = num %10;
        System.out.println(reminder);
        revnum =revnum * 10 +reminder;
        num= num/10;*/

        /*  program to find out the fibonacci series */

        int num1 =6;

        int a=0;
        int b=0;
        int c=1;
        System.out.println("fibonacci");
        while( num1!=0){
            a= b;
            b=c;
            c=a+b;
            System.out.println("a"+a);
            num1--;
        }

        /*  program to find out the duplicate elemnts in the String*/

        String str4 = new String("Sakkett");
   Set<String> duplicate= new LinkedHashSet<>();
        Arrays.stream(str4.split("")).map(data-> data.toLowerCase()).filter( data-> !duplicate.add(data)).collect(Collectors.toSet());
        System.out.println(duplicate);


        Map<String, Long> collect3 =
                Arrays.stream(str4.split("")).
                map(data -> data.toLowerCase())
                .collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));
        System.out.println(collect3);


        List<Map.Entry<String, Long>> collect4 = collect3.entrySet().stream().filter(duplicatedata -> duplicatedata.getValue() > 1).collect(Collectors.toList());
        System.out.println(collect4);


        /* find out 2nd highest in list*/

        Integer arr[] = { 100,14, 46, 47, 94, 94, 52, 86, 36, 94, 89 };
            Arrays.sort(arr);
        System.out.println("+>");
        Stream<Integer> sorted = Arrays.stream(arr)
                .distinct().
                sorted(Comparator.comparing(Function.identity()));
        sorted.forEach(System.out::println);
        Map<Integer, Long> collect5 = Arrays.stream(arr).collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));
        System.out.println(collect5 +"2nd heighest "+ arr[2]);


        String dummy= "swapnil";
        StringBuilder builder1= new StringBuilder(dummy);

       String  rev=builder1.reverse().toString();
        System.out.println("@@@@@@@@@@"+rev);


        System.out.println("???????????????????????????????????????????????");
        String ipp= "swiapnil";

        Map<String, Long> collect6 = Arrays.stream(ipp.split("")).
                map(x1 -> x1.toUpperCase()).
                collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));

        System.out.println(collect6);

        StringBuilder builder2  = new StringBuilder(ipp);
        System.out.println();
        String op="";
       for(int j=ipp.length()-1; j>=0; j--){
           op=op+ipp.charAt(j);
       }
        System.out.println("........................................");
        System.out.println(op);


        System.out.println("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
        String input5= "i am java devloper";



        // count of each letter
        Map<String, Long> collect7 = Arrays.stream(input5.split(""))
                .map(x5 -> x5.toLowerCase())
                .collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));
        System.out.println(collect7);











    }
}

