package com.example.springangulardemo.swapnilme.testme.practice;

import java.util.*;
import java.util.stream.Collectors;

public class Practiceme {
    public static void main(String[] args) {

//Q`1  Given a list of integers, find out all the even numbers exist in the list using Stream functions?

        List<Integer> listofInteger= Arrays.asList(12,2,3,5,24,1,19,30);

        List<Integer> evenNums=listofInteger.stream().filter(num->num % 2==0).collect(Collectors.toList());
        System.out.println(evenNums);
        System.out.println("-------------------------------");


    // Q2 Given a list of integers, find out all the numbers starting with 1 using Stream functions?
        listofInteger.stream().map(integer -> integer +"").filter(s->s.startsWith("1")).forEach(System.out::println);
        System.out.println("-------------------------------");
    // q3 How to find duplicate elements in a given integers list in java using Stream functions?
        List<Integer> myList = Arrays.asList(10,15,8,49,25,98,98,32,15);
       Set<Integer>disctint = myList.stream().collect(Collectors.toSet());
        List<Integer>disctint1 =myList.stream().distinct().collect(Collectors.toList());
        System.out.println(disctint);
        System.out.println(disctint1);
        // ans
        Set<Integer>set = new LinkedHashSet<>();
        System.out.println("-----------------------------");
        myList.stream().filter(d->!set.add(d)).forEach(System.out::println);

        //Q4 Given the list of integers, find the first element of the list using Stream functions?

        List<Integer> myList1 = Arrays.asList(10,15,8,49,25,98,98,32,15);
        System.out.println("-----------------------------");

        myList1.stream().findFirst().ifPresent(System.out::println);
        myList1.stream().findAny().ifPresent(System.out::println);

        //  Q5 Given a list of integers, find the total number of elements present in the list using Stream functions?
        System.out.println("-----------------------------");
        System.out.println(myList.stream().count());

        //Q6 Given a list of integers, find the maximum value element present in it using Stream functions?
        System.out.println("-----------------------------");
        myList.stream().max(Integer::compare).get();
        System.out.println(myList.stream().max(Integer::compare).get());
        System.out.println(myList.stream().max(Integer::max).get());

        //Given a String, find the first non-repeated character in it using Stream functions?
        String input = "Java Hungry Blog Alive is Awesome";
        System.out.println("--------- %%%%%%%%%%%%%--------------------");
         input.chars().mapToObj(x->Character.valueOf((char) x)).distinct();
        System.out.println("-------------");

        System.out.println(        myList1.stream().reduce(0,(a,b)-> a+b));






    }
}
