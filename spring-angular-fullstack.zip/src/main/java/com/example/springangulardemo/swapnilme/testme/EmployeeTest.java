package com.example.springangulardemo.swapnilme.testme;

import java.util.*;
import java.util.stream.Collectors;

public class EmployeeTest {
    public static void main(String[] args) {

        List<Employee> employeeList= new ArrayList<>();
        Employee e1 = new Employee(1,23,"swapnil",new int[] {40,50,23});
        Employee e2 = new Employee(2,25,"dinesh",new int[] {10,20,23});
        Employee e5 = new Employee(5,25,"zuber",new int[] {10,20,23});
        Employee e3 = new Employee(3,24,"pooja",new int[] {40,50,23});
        Employee e4 = new Employee(4,25,"rushikesh",new int[] {20,50,23});
        employeeList.add(e1);
        employeeList.add(e2);
        employeeList.add(e3);
        employeeList.add(e5);
        employeeList.add(e4);
        System.out.println( employeeList);
        System.out.println("**********************************************************************************");

        //  group  by age
       Map<Integer,List<Employee>> groupByAge= employeeList.stream().collect(Collectors.groupingBy(Employee::getAge));
        System.out.println(groupByAge);


        Map<Integer,List<String>> groupByAge1= employeeList.stream().collect(Collectors.groupingBy(Employee::getAge, Collectors.mapping(Employee::getName,Collectors.toList() )));
        System.out.println( groupByAge1 );

        //  using mapping in java 8
        Set<String> employeeSet =employeeList.stream().collect(Collectors.mapping(Employee::getName,Collectors.toSet()));
        String employeeSet1= employeeSet.stream().collect(Collectors.joining("*" ,"[" ,"]"));
        System.out.println(employeeSet1);

        //maxBy

      Optional<Integer> maxAge = employeeList.stream().collect(Collectors.mapping(Employee::getAge,Collectors.maxBy(Integer::compareTo)));
        System.out.println(maxAge);

        //partionlaed by

        Map<Integer,Long>obj =
                employeeList
                        .stream()
                             .collect(Collectors.groupingBy((Employee e) -> e.getAge(),Collectors.counting()));

        System.out.println(obj);


        //
        List<String> list = Arrays.asList("3", "6", "8",
                "14", "15");

        OptionalDouble avg=  list.stream().mapToInt(Integer::parseInt).average();
        System.out.println(avg);

        String input = "swapniln";

         HashMap<Character,Integer> map = new HashMap<Character, Integer>();

         for(int i=0; i< input.length();i++){

             if(map.containsKey(input.charAt(i))){
                  map.put(input.charAt(i),map.get(input.charAt(i)) + 1);
             }else{
                 map.put(input.charAt(i),1);
             }

         }

/*
         System.gc();
*/
         /// sort the emplotyee bas eon the  name

        employeeList.stream().sorted((emp1 ,emp2)-> emp1.getName().compareTo(emp2.getName())).forEach(System.out::println);
        System.out.println("---------------------------------------------------------------------------");
        employeeList.stream().sorted((emp1 ,emp2)-> emp2.getAge()-emp1.getAge()).forEach(System.out::println);



        Collections.sort(employeeList,(ememployee1 ,employee2) -> ememployee1.getAge() -employee2.getAge());
        System.out.println("=======================");
        System.out.println(employeeList);

        // convert list to map
        Map<Integer,Integer> mapofEmployee= employeeList.stream().collect(Collectors.toMap(Employee::getEmpid, Employee::getAge));
        System.out.println("--------");
        System.out.println(mapofEmployee);

        //

        boolean b1= true;
        boolean b2= false;
        int i1=1;
        int i2=2;

        System.out.println((i1|i2) ==3);
        //System.out.println ((i2 && b1));
        System.out.println(b1 || !b2);
        System.out.println((i1 ^ i2)<4);

        Employee employeeObj = employeeList.get(0);
        System.out.println(employeeObj);
        employeeList.add(employeeObj);






        Integer inj=100;
        Integer inj2 = new Integer(100);
        System.out.println("-------------*************-----------------");

        System.out.println(inj.equals(inj2));
        System.out.println(inj==inj2);

        /*if(inj.equals(inj2))  // true
            if(str ==str1) //
*/

























    }
}
