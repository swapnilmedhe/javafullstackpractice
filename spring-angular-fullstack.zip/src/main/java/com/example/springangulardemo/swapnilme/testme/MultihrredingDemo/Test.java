package com.example.springangulardemo.swapnilme.testme.MultihrredingDemo;


import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

class A extends Thread{
    @Override
    public void run() {
       for(int i=0; i< 5 ;i++){
           System.out.println(i);
       }
    }
}

class B extends Thread{
    @Override
    public void run() {
        for(int i=10; i< 15 ;i++){
            System.out.println(i);
        }
    }
}



public class Test extends Thread {

    @Override
    public void run() {
        System.out.println("exicuting _______________");
    }

    public static void main(String[] args) {
  // raise condition:
//        multiple thread are accessing to the same resorse at same time and try to modify.

        // is it possible to start thread twice answer : no
        Test t1 = new Test();
     /*   t1.start();
        t1.start();*/


        // Can we call the run() method instead of start()?
        // ANs : yes    but no contest switching betn threds
        Test t3 = new Test();
        t3.run();

        // sychronized


    }
}
